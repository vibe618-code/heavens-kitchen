import { useState, useRef, useEffect, useMemo } from 'react';
import type { Dish, Translations } from './types';

// --- Image URL helpers ---
const HR = "w=800&q=80&auto=format";
const HRO = "w=1200&q=80&auto=format";
const HRHERO = "w=1920&q=90&auto=format";
const HRAVATAR = "w=200&q=80&auto=format";

export const IMG = { HR, HRO, HRHERO, HRAVATAR };

// --- localStorage helpers ---
export const LS = {
  get(key: string, fallback: unknown = null) {
    try {
      const v = localStorage.getItem(key);
      return v ? JSON.parse(v) : fallback;
    } catch {
      return fallback;
    }
  },
  set(key: string, value: unknown) {
    localStorage.setItem(key, JSON.stringify(value));
  },
  remove(key: string) {
    localStorage.removeItem(key);
  },
};

// --- Translations ---
export const translations: Translations = {
  loading: "CLOUD KITCHEN",
  loginWelcome: "Welcome",
  loginText: "Enter your details to continue",
  name: "Name *",
  phone: "Phone *",
  address: "Address *",
  password: "Password *",
  login: "Login",
  signup: "Sign Up",
  noAccount: "Don't have an account? Sign up",
  hasAccount: "Already have an account? Log in",
  skip: "Skip for now",
  menu: "Menu",
  prevOrders: "Previous Orders",
  loyalty: "Loyalty Coins",
  fav: "Favourites",
  darkMode: "Dark Mode",
  signOut: "Sign Out",
  heroTag: "Premium Cloud Kitchen · Delivery Only",
  heroTitle: "Elevating Everyday Dining",
  heroSub: "Flavor-packed meals from our kitchen to yours.",
  viewMenu: "Full Menu",
  aiSuggester: "AI Menu Recommender",
  cuisinePref: "Filter by category",
  suggest: "Suggest Dishes",
  orderNow: "Add to Cart",
  customize: "Customize",
  addTruffle: "Extra Cheese (+₹20)",
  addCheese: "Extra Sauce (+₹15)",
  noOnion: "No Onion",
  addToCart: "Add to Cart",
  cart: "Cart",
  checkout: "Proceed to Checkout",
  itemTotal: "Item Total",
  placeOrder: "Place Order",
  orderSuccess: "Order Placed Successfully!",
  coinsEarnedMsg: "+10 Coins earned",
  trackOrder: "Track Order",
  confirmed: "Confirmed",
  preparing: "Preparing",
  out: "Out for Delivery",
  delivered: "Delivered",
  coinsEarned: "Coins Earned",
  noOrders: "No previous orders",
  noFav: "No favourites yet",
  noCoins: "No coins earned yet",
  emptyCart: "Your cart is empty",
  redeemPoints: "Redeem Points",
  pointsAvailable: "Loyalty Coins available",
  redeemNote: "10 pts = ₹10 off (max 50 pts)",
  orderAgain: "Order Again",
  dietary: "Dietary",
  veg: "Veg",
  nonVeg: "Non-Veg",
  admin: "Admin Panel",
  adminPass: "Admin Passcode",
  orderHistory: "Order History",
  totalOrders: "Total Orders",
  discountCode: "Discount Code",
  apply: "Apply",
};

// --- Default Dishes ---
const imgMap: Record<string, string> = {
  Mojito: `https://images.unsplash.com/photo-1513558161293-cdaf7652fd2d?${HR}`,
  Milkshake: `https://images.unsplash.com/photo-1572490122747-3968b75cc699?${HR}`,
  Fries: `https://images.unsplash.com/photo-1585109649139-366815a0d713?${HR}`,
  "Special Fries": `https://images.unsplash.com/photo-1599974579688-8dbdd335c77f?${HR}`,
  Burger: `https://images.unsplash.com/photo-1568901346375-23c9450c58cd?${HR}`,
  Sandwich: `https://images.unsplash.com/photo-1528735602780-2552fd46c7af?${HR}`,
  Wrap: `https://images.unsplash.com/photo-1626700051175-6818013e1d4f?${HR}`,
  Pizza: `https://images.unsplash.com/photo-1565299624946-b28f40a0ae38?${HR}`,
  "Sliders / Sides": `https://images.unsplash.com/photo-1562967916-eb82221dfb92?${HR}`,
};

export const DEFAULT_DISHES: Dish[] = (() => {
  let id = 1;
  const items: Dish[] = [];
  const addItem = (cat: string, title: string, price: number, image: string, dietary: 'veg' | 'non-veg' = 'non-veg') =>
    items.push({ id: id++, category: cat, title, price, image, dietary, inStock: true });

  ["Blue Curacao", "Watermelon", "Strawberry", "Virgin"].forEach((n) =>
    addItem("Mojito", `${n} Mojito`, 70, imgMap.Mojito, 'veg')
  );
  [
    ["Vanilla", 90], ["Strawberry", 100], ["Butter Scotch", 100],
    ["Black Current", 100], ["Chocolate", 110], ["Oreo", 120],
  ].forEach(([n, p]) => addItem("Milkshake", `${n} Milkshake`, p as number, imgMap.Milkshake, 'veg'));

  addItem("Fries", "Salted Fries (Regular)", 70, imgMap.Fries, 'veg');
  addItem("Fries", "Salted Fries (Large)", 100, imgMap.Fries, 'veg');
  addItem("Fries", "Peri Peri Fries (Regular)", 90, imgMap.Fries, 'veg');
  addItem("Fries", "Peri Peri Fries (Large)", 130, imgMap.Fries, 'veg');
  addItem("Special Fries", "Chicken Loaded Fries", 160, imgMap["Special Fries"], 'non-veg');
  addItem("Special Fries", "Chicken Cheesy Fries", 180, imgMap["Special Fries"], 'non-veg');
  addItem("Special Fries", "Full Chicken Loaded Fries", 200, imgMap["Special Fries"], 'non-veg');
  addItem("Special Fries", "Special Loaded Chicken", 250, imgMap["Special Fries"], 'non-veg');

  [
    ["Chicken Burger", 120], ["Chicken Nuggets Burger", 120], ["Chicken Cheesy Burger", 130],
    ["Chicken Zinger Burger", 130], ["Chicken Loaded Burger", 150], ["Chicken Cheesy Loaded", 190],
  ].forEach(([n, p]) => addItem("Burger", n as string, p as number, imgMap.Burger, 'non-veg'));

  addItem("Sandwich", "Veg Sandwich", 70, imgMap.Sandwich, 'veg');
  addItem("Sandwich", "Veg Cheese Sandwich", 90, imgMap.Sandwich, 'veg');
  addItem("Sandwich", "Chicken Sandwich", 90, imgMap.Sandwich, 'non-veg');
  addItem("Sandwich", "BBQ Chicken Sandwich", 100, imgMap.Sandwich, 'non-veg');
  addItem("Sandwich", "Chicken Cheesy Sandwich", 110, imgMap.Sandwich, 'non-veg');
  addItem("Sandwich", "Heavens Sandwich", 120, imgMap.Sandwich, 'non-veg');

  [
    ["Chicken Wrap", 120], ["Chicken BBQ Wrap", 120], ["Chicken Tandoori Wrap", 120],
    ["Chicken Nuggets Wrap", 130], ["Chicken Cheesy Wrap", 130], ["Chicken Zinger Wrap", 130],
    ["Chicken Loaded Wrap", 160],
  ].forEach(([n, p]) => addItem("Wrap", n as string, p as number, imgMap.Wrap, 'non-veg'));

  addItem("Pizza", 'Veg Pizza 8"', 170, imgMap.Pizza, 'veg');
  addItem("Pizza", 'Magrherita 8"', 170, imgMap.Pizza, 'veg');
  addItem("Pizza", 'Veg Heavens Pizza 8"', 190, imgMap.Pizza, 'veg');
  addItem("Pizza", 'Chicken Pizza 8"', 190, imgMap.Pizza, 'non-veg');
  addItem("Pizza", 'BBQ Chicken Pizza 8"', 200, imgMap.Pizza, 'non-veg');
  addItem("Pizza", 'Cheesy Chicken Pizza 8"', 230, imgMap.Pizza, 'non-veg');
  addItem("Pizza", 'Chicken Heavens Pizza 8"', 240, imgMap.Pizza, 'non-veg');

  addItem("Sliders / Sides", "Chicken Nuggets (8 Pcs)", 100, imgMap["Sliders / Sides"], 'non-veg');
  addItem("Sliders / Sides", "Chicken Nuggets (15 Pcs)", 170, imgMap["Sliders / Sides"], 'non-veg');
  addItem("Sliders / Sides", "Chicken Popcorn (15 Pcs)", 100, imgMap["Sliders / Sides"], 'non-veg');
  addItem("Sliders / Sides", "Chicken Strips (5 Pcs)", 200, imgMap["Sliders / Sides"], 'non-veg');

  return items;
})();

export const specialsTitles = [
  "Chicken Loaded Fries", "Chicken Cheesy Fries", "Full Chicken Loaded Fries", "Special Loaded Chicken",
];

export const categoryOrder = [
  "Sandwich", "Burger", "Fries", "Pizza", "Wrap", "Sliders / Sides", "Milkshake", "Mojito",
];

// --- Custom Hooks ---
export function useInView(threshold = 0.2) {
  const [inView, setInView] = useState(false);
  const ref = useRef<HTMLElement>(null);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const obs = new IntersectionObserver(
      ([e]) => {
        if (e.isIntersecting) {
          setInView(true);
          obs.unobserve(el);
        }
      },
      { threshold }
    );
    obs.observe(el);
    return () => obs.disconnect();
  }, [threshold]);
  return [ref, inView] as const;
}

export function useFocusTrap(ref: React.RefObject<HTMLElement | null>, isOpen: boolean) {
  useEffect(() => {
    if (!isOpen || !ref.current) return;
    const focusable = 'a, button, input, select, textarea, [tabindex]';
    const trap = ref.current;
    const els = trap.querySelectorAll(focusable);
    const first = els[0] as HTMLElement;
    const last = els[els.length - 1] as HTMLElement;
    const handler = (e: KeyboardEvent) => {
      if (e.key === 'Tab') {
        if (e.shiftKey && document.activeElement === first) {
          e.preventDefault();
          last?.focus();
        } else if (!e.shiftKey && document.activeElement === last) {
          e.preventDefault();
          first?.focus();
        }
      }
    };
    trap.addEventListener('keydown', handler);
    if (first) first.focus();
    return () => trap.removeEventListener('keydown', handler);
  }, [isOpen, ref]);
}

export function useSparkles(count = 45) {
  return useMemo(
    () =>
      Array.from({ length: count }, (_, i) => ({
        id: i,
        left: Math.random() * 100,
        top: Math.random() * 100,
        size: 2 + Math.random() * 5,
        delay: Math.random() * 8,
        duration: 5 + Math.random() * 12,
      })),
    [count]
  );
}

export function useFloatingItems() {
  return useMemo(
    () => [
      { icon: "fa-burger", left: "5%", delay: "0s", duration: "8s" },
      { icon: "fa-french-fries", left: "20%", delay: "1s", duration: "9s" },
      { icon: "fa-mug-saucer", left: "45%", delay: "2s", duration: "7.5s" },
      { icon: "fa-pizza-slice", left: "70%", delay: "0.5s", duration: "10s" },
      { icon: "fa-taco", left: "85%", delay: "1.5s", duration: "8.5s" },
      { icon: "fa-ice-cream", left: "15%", delay: "2.5s", duration: "9.5s" },
      { icon: "fa-drumstick-bite", left: "60%", delay: "3s", duration: "7s" },
      { icon: "fa-carrot", left: "40%", delay: "0.8s", duration: "8.2s" },
    ],
    []
  );
}
