import { useState, useEffect, useMemo, useCallback } from 'react';
import type { Translations, Dish } from '../types';
import { useInView, IMG, categoryOrder } from '../utils';
import { SkeletonCard } from './UIComponents';

// ---- Hero ----
export const Hero = ({ t }: { t: Translations }) => {
  const [ref, inView] = useInView(0.1);
  return (
    <section id="hero" ref={ref} className="relative min-h-screen flex items-center justify-center overflow-hidden">
      <div className="absolute inset-0">
        <img
          src={`https://images.unsplash.com/photo-1504674900247-0877df9cc836?${IMG.HRHERO}`}
          className="w-full h-full object-cover"
          alt="Food background"
        />
      </div>
      <div className="relative z-10 text-center px-6 max-w-4xl mx-auto">
        <p
          className={`text-white uppercase tracking-[0.3em] text-sm mb-6 hero-text-shadow transition-all ${inView ? 'opacity-100' : 'opacity-0 translate-y-6'}`}
        >
          {t.heroTag}
        </p>
        <h1
          className={`font-display text-5xl md:text-7xl font-bold text-white mb-8 hero-text-shadow transition-all ${inView ? 'opacity-100' : 'opacity-0 translate-y-8'}`}
        >
          {t.heroTitle}
        </h1>
        <p
          className={`text-white/90 text-lg mb-10 hero-text-shadow transition-all ${inView ? 'opacity-100' : 'opacity-0 translate-y-6'}`}
        >
          {t.heroSub}
        </p>
        <a
          href="#menu"
          className="px-10 py-4 bg-velvet-red text-white rounded-full font-semibold shadow-xl hover:bg-red-velvet active:scale-95 transition inline-block"
        >
          {t.viewMenu}
        </a>
      </div>
    </section>
  );
};

// ---- OurStory ----
export const OurStory = ({ storyImg }: { t?: Translations; storyImg?: string }) => {
  const [ref] = useInView(0.2);
  return (
    <section ref={ref} className="w-full max-w-7xl mx-auto px-6 py-16 md:py-24">
      <div className="grid md:grid-cols-2 gap-12 lg:gap-20 items-center">
        <div className="relative order-2 md:order-1">
          <div className="aspect-[4/5] rounded-3xl overflow-hidden shadow-2xl image-hover-zoom float-frame">
            <img
              src={storyImg || `https://images.unsplash.com/photo-1577219491135-ce391730fb2c?${IMG.HRO}`}
              alt="Chef plating a gourmet dish"
              className="w-full h-full object-cover"
              loading="lazy"
            />
          </div>
        </div>
        <div className="order-1 md:order-2">
          <p className="text-velvet-red uppercase tracking-[0.25em] text-sm font-semibold mb-4">Our Story</p>
          <h2 className="font-display text-4xl md:text-5xl font-bold text-dark-chocolate dark:text-cream mb-6 leading-tight">
            Redefining Gourmet <span className="italic text-velvet-red">Delivery</span>
          </h2>
          <p className="text-dark-chocolate/70 dark:text-cream/70 leading-relaxed mb-5 text-lg">
            Founded in 2021, Cloud Kitchen Co. was born from a passion for exceptional food and a desire to make fine dining accessible at home.
          </p>
          <p className="text-dark-chocolate/70 dark:text-cream/70 leading-relaxed mb-8 text-lg">
            Our team of award‑winning chefs sources the finest ingredients and crafts menus that blend global techniques with local flavours.
          </p>
          <div className="grid grid-cols-3 gap-6 pt-4">
            <div className="text-center">
              <p className="font-display text-3xl lg:text-4xl font-bold text-velvet-red">10k+</p>
              <p className="text-sm mt-1">Orders Delivered</p>
            </div>
            <div className="text-center">
              <p className="font-display text-3xl lg:text-4xl font-bold text-velvet-red">4.9</p>
              <p className="text-sm mt-1">Average Rating</p>
            </div>
            <div className="text-center">
              <p className="font-display text-3xl lg:text-4xl font-bold text-velvet-red">5</p>
              <p className="text-sm mt-1">Cities Served</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

// ---- TestimonialsSlider ----
export const TestimonialsSlider = () => {
  const testimonials = [
    {
      name: 'Riya & Arjun Mehta',
      location: 'Mumbai',
      text: 'The food from Cloud Kitchen Co. rivals any fine dining restaurant. Every bite was a revelation!',
      image: `https://images.unsplash.com/photo-1494790108377-be9c29b29330?${IMG.HRAVATAR}`,
    },
    {
      name: 'Vikram Singh',
      location: 'Delhi',
      text: 'I ordered the truffle risotto for a date night at home – perfection. Delivery was prompt and hot.',
      image: `https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?${IMG.HRAVATAR}`,
    },
    {
      name: 'Ananya Patel',
      location: 'Bangalore',
      text: 'Their event catering transformed our anniversary dinner. Five stars! Unforgettable experience.',
      image: `https://images.unsplash.com/photo-1438761681033-6461ffad8d80?${IMG.HRAVATAR}`,
    },
  ];
  const [current, setCurrent] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrent((prev) => (prev + 1) % testimonials.length);
    }, 5000);
    return () => clearInterval(interval);
  }, [testimonials.length]);

  return (
    <section className="w-full max-w-5xl mx-auto px-6 py-16 md:py-24 text-center">
      <p className="text-velvet-red uppercase tracking-[0.25em] text-sm font-semibold mb-4">Testimonials</p>
      <h2 className="font-display text-4xl md:text-5xl font-bold mb-12">
        What Our <span className="italic text-velvet-red">Customers</span> Say
      </h2>
      <div className="relative overflow-hidden min-h-[320px]">
        <div
          className="testimonial-track"
          style={{ transform: `translateX(-${current * 100}%)` }}
        >
          {testimonials.map((t, idx) => (
            <div key={idx} className="testimonial-slide">
              <div className="glass-card rounded-3xl p-8 md:p-10 max-w-2xl mx-auto float-frame">
                <div className="flex justify-center mb-4 text-velvet-red text-2xl">{'★'.repeat(5)}</div>
                <p className="text-dark-chocolate/80 dark:text-cream/80 text-lg leading-relaxed italic mb-6">
                  &ldquo;{t.text}&rdquo;
                </p>
                <div className="flex items-center justify-center gap-4">
                  <img
                    src={t.image}
                    alt={t.name}
                    className="w-14 h-14 rounded-full object-cover ring-2 ring-velvet-red/40"
                    loading="lazy"
                  />
                  <div className="text-left">
                    <p className="font-semibold">{t.name}</p>
                    <p className="text-sm">{t.location}</p>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
      <div className="flex justify-center gap-3 mt-8">
        {testimonials.map((_, idx) => (
          <div
            key={idx}
            className={`dot ${idx === current ? 'active' : ''}`}
            onClick={() => setCurrent(idx)}
          ></div>
        ))}
      </div>
    </section>
  );
};

// ---- MenuGallery ----
export const MenuGallery = ({
  t,
  dishes,
  onOrder,
  favorites,
  toggleFavorite,
  dietaryFilter,
  setDietaryFilter,
}: {
  t: Translations;
  dishes: Dish[];
  onOrder: (dish: Dish) => void;
  favorites: number[];
  toggleFavorite: (id: number) => void;
  dietaryFilter: string;
  setDietaryFilter: (f: string) => void;
}) => {
  const orderedCategories = useMemo(() => {
    const existing = new Set(dishes.map((d) => d.category));
    return categoryOrder.filter((c) => existing.has(c));
  }, [dishes]);

  const [filter, setFilter] = useState(orderedCategories[0] || '');
  const [loading, setLoading] = useState(false);

  const filtered = useMemo(() => {
    let d = dishes.filter((d) => d.category === filter);
    if (dietaryFilter !== 'all') d = d.filter((d) => d.dietary === dietaryFilter);
    return d.sort((a, b) => {
      const idxA = categoryOrder.indexOf(a.category);
      const idxB = categoryOrder.indexOf(b.category);
      return idxA - idxB;
    });
  }, [filter, dietaryFilter, dishes]);

  useEffect(() => {
    setLoading(true);
    const t = setTimeout(() => setLoading(false), 300);
    return () => clearTimeout(t);
  }, [filter, dietaryFilter]);

  return (
    <section id="menu" className="py-24 bg-soft-beige dark:bg-dark-chocolate/60 px-6">
      <div className="max-w-7xl mx-auto">
        <h2 className="font-display text-4xl font-bold text-center mb-8">{t.viewMenu}</h2>
        <div className="flex flex-wrap justify-center gap-3 mb-4">
          {orderedCategories.map((c) => (
            <button
              key={c}
              onClick={() => setFilter(c)}
              className={`category-tag px-6 py-2 rounded-full text-base font-semibold tracking-wide transition active:scale-95 ${
                filter === c
                  ? 'bg-velvet-red text-white'
                  : 'bg-white dark:bg-dark-chocolate text-dark-chocolate dark:text-cream'
              }`}
            >
              {c}
            </button>
          ))}
        </div>
        <div className="flex justify-center gap-3 mb-10">
          <button
            onClick={() => setDietaryFilter('all')}
            className={`px-4 py-1 rounded-full text-sm font-medium transition active:scale-95 ${
              dietaryFilter === 'all'
                ? 'bg-accent-secondary text-dark-chocolate'
                : 'bg-white dark:bg-dark-chocolate'
            }`}
          >
            {t.dietary}: All
          </button>
          <button
            onClick={() => setDietaryFilter('veg')}
            className={`px-4 py-1 rounded-full text-sm font-medium transition active:scale-95 ${
              dietaryFilter === 'veg'
                ? 'bg-green-500 text-white'
                : 'bg-white dark:bg-dark-chocolate'
            }`}
          >
            🥬 {t.veg}
          </button>
          <button
            onClick={() => setDietaryFilter('non-veg')}
            className={`px-4 py-1 rounded-full text-sm font-medium transition active:scale-95 ${
              dietaryFilter === 'non-veg'
                ? 'bg-red-500 text-white'
                : 'bg-white dark:bg-dark-chocolate'
            }`}
          >
            🍗 {t.nonVeg}
          </button>
        </div>
        <div className="masonry-grid">
          {loading
            ? Array.from({ length: 6 }).map((_, i) => <SkeletonCard key={i} />)
            : filtered
                .filter((d) => d.inStock !== false)
                .map((dish) => (
                  <div
                    key={dish.id}
                    className="masonry-item rounded-2xl overflow-hidden shadow-lg group float-frame"
                  >
                    <div className="image-hover-zoom">
                      <img src={dish.image} className="w-full h-56 object-cover" loading="lazy" alt={dish.title} />
                    </div>
                    <div className="menu-item-bar p-4 flex justify-between items-center">
                      <div>
                        <h3 className="menu-item-title font-bold text-xl">{dish.title}</h3>
                        <p className="text-sm font-bold text-velvet-red">₹{dish.price}</p>
                        <span
                          className={`text-xs px-2 py-0.5 rounded-full ${
                            dish.dietary === 'veg'
                              ? 'bg-green-100 text-green-700'
                              : 'bg-red-100 text-red-700'
                          }`}
                        >
                          {dish.dietary === 'veg' ? '🥬 Veg' : '🍗 Non-Veg'}
                        </span>
                      </div>
                      <div className="flex gap-2 items-center">
                        <button onClick={() => toggleFavorite(dish.id)} className="text-xl">
                          <i
                            className={`fas fa-heart ${
                              favorites.includes(dish.id) ? 'text-velvet-red' : 'text-gray-500'
                            }`}
                          ></i>
                        </button>
                        <button
                          onClick={() => onOrder(dish)}
                          className="add-to-cart-btn px-4 py-1.5 rounded-full text-sm font-semibold shadow-md active:scale-95"
                        >
                          {t.orderNow}
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
        </div>
      </div>
    </section>
  );
};

// ---- SignatureDishes ----
export const SignatureDishes = ({
  t,
  specials,
  onOrder,
}: {
  t: Translations;
  specials: Dish[];
  onOrder: (dish: Dish) => void;
}) => (
  <section className="py-24 px-6">
    <h2 className="font-display text-4xl font-bold text-center mb-10">
      Chef's <span className="italic text-velvet-red">Specials</span>
    </h2>
    <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8 max-w-7xl mx-auto">
      {specials.map((dish) => (
        <div key={dish.id} className="glass-card rounded-2xl overflow-hidden float-frame">
          <div className="image-hover-zoom h-64">
            <img src={dish.image} className="w-full h-full object-cover" loading="lazy" alt={dish.title} />
          </div>
          <div className="p-6">
            <h3 className="menu-item-title font-bold text-xl">{dish.title}</h3>
            <p className="text-velvet-red font-bold text-lg">₹{dish.price}</p>
            <button
              onClick={() => onOrder(dish)}
              className="add-to-cart-btn mt-3 px-4 py-2 rounded-full text-sm font-semibold active:scale-95"
            >
              {t.orderNow}
            </button>
          </div>
        </div>
      ))}
    </div>
  </section>
);

// ---- Footer ----
export const Footer = ({
  onAdminClick,
}: {
  t?: Translations;
  onAdminClick: () => void;
}) => (
  <footer className="py-12 border-t text-center">
    <div className="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-center gap-4 px-6">
      <a href="#hero" className="font-display text-2xl font-bold">
        CLOUD KITCHEN<span className="text-red-velvet">.</span>
      </a>
      <p>&copy; 2026 Cloud Kitchen Co.</p>
      <div className="flex gap-6 items-center">
        <a href="#" onClick={(e) => { e.preventDefault(); alert('Privacy Policy placeholder'); }}>
          Privacy
        </a>
        <a href="#" onClick={(e) => { e.preventDefault(); alert('Terms of Service placeholder'); }}>
          Terms
        </a>
        <button onClick={onAdminClick} className="text-sm hover:underline opacity-70 hover:opacity-100 transition">
          Admin
        </button>
      </div>
    </div>
  </footer>
);

// ---- HamburgerMenu ----
export const HamburgerMenu = ({
  t,
  isOpen,
  onClose,
  darkMode,
  onToggleDarkMode,
  onNavigate,
  userName,
  loyaltyPoints,
}: {
  t: Translations;
  isOpen: boolean;
  onClose: () => void;
  darkMode: boolean;
  onToggleDarkMode: () => void;
  onNavigate: (action: string) => void;
  userName: string;
  loyaltyPoints: number;
}) => {
  const [closing, setClosing] = useState(false);

  const handleClose = useCallback(() => {
    setClosing(true);
    setTimeout(() => {
      setClosing(false);
      onClose();
    }, 280);
  }, [onClose]);

  useEffect(() => {
    document.body.style.overflow = isOpen ? 'hidden' : '';
    return () => { document.body.style.overflow = ''; };
  }, [isOpen]);

  if (!isOpen && !closing) return null;

  const greeting = () => {
    const h = new Date().getHours();
    return h < 12 ? 'Good Morning' : h < 17 ? 'Good Afternoon' : 'Good Evening';
  };

  return (
    <div className="fixed inset-0 z-50 flex">
      <div
        className={`absolute inset-0 bg-black/60 ${closing ? 'backdrop-exit' : 'backdrop-enter'}`}
        onClick={handleClose}
      ></div>
      <div
        className={`relative slim-sidebar h-full overflow-y-auto shadow-2xl flex flex-col ${closing ? 'drawer-exit' : 'drawer-enter'}`}
        style={{
          backgroundColor: darkMode ? '#2d221f' : '#FFF5E6',
          color: darkMode ? '#e8e4df' : '#2C2420',
        }}
      >
        <button
          onClick={handleClose}
          className="absolute top-4 right-4 z-10 w-10 h-10 flex items-center justify-center rounded-full bg-white/50 dark:bg-black/20 hover:bg-gray-200 dark:hover:bg-gray-700 transition text-xl"
        >
          <i className="fas fa-times"></i>
        </button>
        <div className="px-5 pt-10 pb-6 border-b">
          <div className="flex items-center gap-3">
            <div className="relative">
              <div className="w-12 h-12 rounded-full bg-velvet-red flex items-center justify-center text-white text-lg font-bold">
                {userName?.charAt(0) || 'G'}
              </div>
            </div>
            <div>
              <p className="font-display text-base font-semibold">
                {greeting()}, {userName || 'Guest'}
              </p>
              <span className="inline-block mt-0.5 text-[10px] font-semibold bg-accent-secondary/20 text-accent-secondary px-2 py-0.5 rounded-full">
                Gold • {loyaltyPoints} pts
              </span>
            </div>
          </div>
        </div>
        <nav className="px-3 mt-5 flex-1 space-y-0.5">
          {[
            { action: 'orders', label: t.prevOrders, icon: 'fas fa-clipboard-list' },
            { action: 'loyalty', label: t.loyalty, icon: 'fas fa-coins' },
            { action: 'fav', label: t.fav, icon: 'fas fa-heart' },
          ].map((link, i) => (
            <div key={link.action} style={{ animationDelay: `${i * 70}ms` }}>
              <button
                onClick={() => {
                  onNavigate(link.action);
                  handleClose();
                }}
                className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl hover:bg-white/20 dark:hover:bg-black/20 transition text-left"
              >
                <i className={`${link.icon} text-base w-5`}></i>
                <span className="font-body text-sm font-medium cart-hd-text">{link.label}</span>
                <i className="fas fa-chevron-right ml-auto text-gray-400 text-xs"></i>
              </button>
            </div>
          ))}
        </nav>
        <div className="px-4 py-5 border-t mt-auto space-y-2">
          <button
            onClick={onToggleDarkMode}
            className="w-full flex items-center justify-between px-3 py-2.5 rounded-xl bg-white/30 dark:bg-black/20 hover:bg-white/40 transition text-sm"
          >
            <span className="flex items-center gap-2">
              <i className={`fas ${darkMode ? 'fa-sun' : 'fa-moon'} text-base`}></i>
              <span className="font-medium text-sm cart-hd-text">{t.darkMode}</span>
            </span>
            <div
              className={`w-9 h-5 rounded-full relative transition ${darkMode ? 'bg-velvet-red' : 'bg-gray-400'}`}
            >
              <div
                className={`absolute top-0.5 w-4 h-4 rounded-full bg-white shadow transition ${darkMode ? 'left-4' : 'left-0.5'}`}
              ></div>
            </div>
          </button>
          <button
            onClick={() => {
              onNavigate('signout');
              handleClose();
            }}
            className="w-full flex items-center gap-2 px-3 py-2.5 rounded-xl text-gray-500 dark:text-gray-400 hover:bg-white/20 transition text-sm"
          >
            <i className="fas fa-sign-out-alt text-sm"></i>
            <span>{t.signOut}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
